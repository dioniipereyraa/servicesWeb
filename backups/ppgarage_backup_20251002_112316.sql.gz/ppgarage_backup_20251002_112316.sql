-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: ppgarageGastos
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `servicio` varchar(100) NOT NULL,
  `montoCobrado` int NOT NULL,
  `tipo_tratamiento` enum('basico','encerado','sellado','premium') DEFAULT 'basico',
  `fecha_ultimo_tratamiento` date DEFAULT NULL,
  `frecuencia_recomendada` int DEFAULT '30' COMMENT 'DÃ­as entre tratamientos',
  `notas_tratamiento` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (5,'Lavados Pago conjunto','Lavado',120000,'basico',NULL,30,NULL),(6,'Lavados Pago conjunto Camionetas','Lavado',80000,'basico',NULL,30,NULL),(7,'Cos','Lavado',30000,'basico',NULL,30,NULL),(8,'Trabajo con marian','Lavado de interior y motor',30000,'basico',NULL,30,NULL),(9,'Daniela Bocchio','Pre-venta completo',45000,'premium',NULL,30,NULL),(10,'Mensualidad','none',150000,'basico',NULL,30,NULL);
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_pdf`
--

DROP TABLE IF EXISTS `configuracion_pdf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion_pdf` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_empresa` varchar(255) DEFAULT 'PPGarage - Car Detailing',
  `direccion_empresa` varchar(255) DEFAULT 'Tu DirecciÃ³n, Ciudad',
  `telefono_empresa` varchar(50) DEFAULT '+54 11 1234-5678',
  `email_empresa` varchar(100) DEFAULT 'contacto@ppgarage.com',
  `encabezado_presupuesto` text,
  `descripcion_empresa` text,
  `terminos_condiciones` text,
  `pie_pagina` text,
  `validez_dias` int DEFAULT '15',
  `fecha_actualizacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `color_primario` varchar(7) DEFAULT '#2980b9' COMMENT 'Color principal en formato hex',
  `color_secundario` varchar(7) DEFAULT '#34495e' COMMENT 'Color secundario en formato hex',
  `logo_url` varchar(500) DEFAULT NULL COMMENT 'URL o ruta del logo de la empresa',
  `mostrar_logo` tinyint(1) DEFAULT '0' COMMENT 'Si mostrar o no el logo en el PDF',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_pdf`
--

LOCK TABLES `configuracion_pdf` WRITE;
/*!40000 ALTER TABLE `configuracion_pdf` DISABLE KEYS */;
INSERT INTO `configuracion_pdf` VALUES (1,'PPGarage - Car Detailing','Uriburu 214, Adrogue','+54 11 6576 9899','ppgarage@gmail.com','Presupuesto de Servicios de Car Detailing','Especialistas en cuidado automotriz con mas de 1 año de experiencia y certificación profesional.','©Términos y Condiciones:\n- El presupuesto tiene validez por los di­as indicados\n- Los precios incluyen materiales y mano de obra\n- Se requiere 50% de seña para iniciar el trabajo\n- Los trabajos se realizan con cita previa','Gracias por confiar en PPGarage - Su vehículo en las mejores manos',15,'2025-10-01 14:04:38','#b82828','#292929','/uploads/logos/logo-1759326686744-321000334.jpeg',1);
/*!40000 ALTER TABLE `configuracion_pdf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gastos`
--

DROP TABLE IF EXISTS `gastos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gastos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  `monto` int NOT NULL,
  `cantidadEnLts` int NOT NULL,
  `fecha` date NOT NULL,
  `estado` enum('activo','terminado') DEFAULT 'activo',
  `lavados_realizados` int DEFAULT NULL,
  `observaciones` text,
  `fecha_baja` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gastos`
--

LOCK TABLES `gastos` WRITE;
/*!40000 ALTER TABLE `gastos` DISABLE KEYS */;
INSERT INTO `gastos` VALUES (6,'APC',10500,3,'2025-08-04','terminado',18,NULL,'2025-10-01'),(7,'Shampoo',4500,1,'2025-08-04','terminado',14,NULL,'2025-10-01'),(8,'Descontaminante Ferrico',6000,1,'2025-08-04','terminado',12,NULL,'2025-10-01'),(9,'Silicona',16000,1,'2025-08-08','terminado',12,NULL,'2025-10-01'),(10,'Acondicionador de Interiores',8000,1,'2025-09-02','activo',NULL,NULL,NULL),(11,'Menzerna 400 HC',26666,1,'2025-09-23','activo',NULL,NULL,NULL),(12,'Menzerna 3800 P',26666,1,'2025-09-23','activo',NULL,NULL,NULL),(13,'Menzerna 3 en 1',26666,1,'2025-09-23','activo',NULL,NULL,NULL),(14,'Cera Vonixx Blend',30000,1,'2025-09-23','activo',NULL,NULL,NULL),(19,'Silicona',18000,1,'2025-10-02','activo',NULL,NULL,NULL),(20,'Shampoo',18000,5,'2025-10-02','activo',NULL,NULL,NULL);
/*!40000 ALTER TABLE `gastos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gastos_maquinas`
--

DROP TABLE IF EXISTS `gastos_maquinas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gastos_maquinas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `marca` varchar(100) DEFAULT NULL,
  `modelo` varchar(100) DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `fecha_compra` date NOT NULL,
  `garantia_meses` int DEFAULT NULL,
  `estado` enum('nueva','usada','mantenimiento','averiada','vendida') DEFAULT 'nueva',
  `observaciones` text,
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gastos_maquinas`
--

LOCK TABLES `gastos_maquinas` WRITE;
/*!40000 ALTER TABLE `gastos_maquinas` DISABLE KEYS */;
INSERT INTO `gastos_maquinas` VALUES (4,'Pulidora','Daihatsu',NULL,216000.00,'2025-10-01',12,'nueva',NULL,'2025-10-01 13:11:19'),(9,'Cepillo para taladro','Laffitte','Cerdas suaves',15000.00,'2025-09-23',1,'nueva',NULL,'2025-10-01 23:32:58'),(10,'Pinceles cerda suave x3','Laffitte','Cerdas suaves',8000.00,'2025-10-01',1,'nueva',NULL,'2025-10-01 23:33:40'),(11,'Cepillo para llantas','Laffitte','Para rueda',9000.00,'2025-09-23',1,'nueva',NULL,'2025-10-01 23:34:06');
/*!40000 ALTER TABLE `gastos_maquinas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `precios_servicios`
--

DROP TABLE IF EXISTS `precios_servicios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `precios_servicios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_servicio` varchar(100) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `descripcion` text,
  `activo` tinyint(1) DEFAULT '1',
  `fecha_actualizacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre_servicio` (`nombre_servicio`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `precios_servicios`
--

LOCK TABLES `precios_servicios` WRITE;
/*!40000 ALTER TABLE `precios_servicios` DISABLE KEYS */;
INSERT INTO `precios_servicios` VALUES (7,'lavado_exterior_basico',15000.00,'',1,'2025-10-01 13:16:21'),(8,'lavado_exterior_premium',20000.00,'Incluye lavado de rejillas e insignias con pincel',1,'2025-10-01 13:16:57'),(9,'lavado_exterior_detallado',25000.00,'Incluye encerado y lavado de burletes e insignias con pincel',1,'2025-10-01 13:17:22'),(10,'limpieza_de_interior_basica',17500.00,'aspirado y limpieza de suciedad pesada',1,'2025-10-01 13:18:00'),(11,'limpieza_de_interior_premium',22500.00,'limpieza de plasticos y alfombras',1,'2025-10-01 13:18:30'),(12,'limpieza_de_interior_profunda',80000.00,'Desarme de butacas, limpieza de tapizados, parantes y plasticos al detalle, incluye acondicionado de interior',1,'2025-10-01 13:19:08'),(13,'acondicionado_de_interior',8000.00,'Hidratacion de plasticos y cuero interiores',1,'2025-10-01 13:19:50'),(14,'lavado_completo_diamante',110000.00,'Limpieza de interior profunda + lavado de motor + lavado de carroceria detallada + encerado con proteccion de 4 meses',1,'2025-10-01 13:20:44'),(15,'encerado_premium',15000.00,'Duracion de 4 meses, aplicado una vez que se lavo la carroceria',1,'2025-10-01 13:21:15'),(16,'lavado_de_bajo_chasis',65000.00,'Limpieza completa de bajo chasis',1,'2025-10-01 13:21:47'),(17,'tratamiento_acrilico',220000.00,'Pulido de 3 etapas + sellado acrilico con duracion de 6 meses',1,'2025-10-01 13:22:36'),(18,'tratamiento_ceramico',240000.00,'Pulido de 3 etapas (correccion barniz) + sellado ceramico con proteccion por 12 meses',1,'2025-10-01 13:23:19'),(19,'servicio_preventa',150000.00,'Lavado de carroceria al detalle + lavado de motor + limpieza interior premium + abrillantado (corrige micro rayas) + encerado premium + acondicionado de interior completo',1,'2025-10-01 13:24:34'),(20,'lavado_de_motor_premium',30000.00,'',1,'2025-10-01 13:25:11'),(21,'lavado_de_motor_detallado',45000.00,'Inluye acondicionado ',1,'2025-10-01 13:25:34'),(22,'combo_escencial_autos',30000.00,'Lavado de carroceria + Limpieza de interior',1,'2025-10-01 23:40:13'),(23,'combo_escencial_camionetas',40000.00,'',1,'2025-10-01 23:40:39');
/*!40000 ALTER TABLE `precios_servicios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'ppgarageGastos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-02 14:23:16
